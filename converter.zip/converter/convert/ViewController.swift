//
//  ViewController.swift
//  convert
//
//  Created by 刘星 on 1/31/18.
//  Copyright © 2018 Xing Liu. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet var tfFa:UITextField!
    @IBOutlet var tfCe:UITextField!
    
   @IBAction func convert(sender:AnyObject){
    var tempInC: Float
    var tempInF: Float
    
   if  let inText = tfFa.text, !inText.isEmpty {
        if let tempInF = Float(inText) {
        tempInC = (tempInF-32)*5/9
        tfCe.text = String(tempInC)
    }else {
        tfCe.text = "???"
    }
   
    } else {
        tfCe.text = "???"
    }
     tfFa.resignFirstResponder()
    }
   
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

