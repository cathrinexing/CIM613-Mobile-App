//
//  Player.swift
//  ratings
//
//  Created by 刘星 on 4/3/18.
//  Copyright © 2018 Xing Liu. All rights reserved.
//

import Foundation

struct Player {
    
    // MARK: - Properties
    var name: String?
    var game: String?
    var rating: Int
}
