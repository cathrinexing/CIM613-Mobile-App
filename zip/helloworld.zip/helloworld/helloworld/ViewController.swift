//
//  ViewController.swift
//  helloworld
//
//  Created by 刘星 on 1/21/18.
//  Copyright © 2018 Xing Liu. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet var hiLabel:UILabel!
    let message = "Hello World!"
    
    @IBAction func showMessage(sender: AnyObject){
        hiLabel.text=message
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

